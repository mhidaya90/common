
import psycopg2 as psy
import pandas as pd
import re
import random
from openai import OpenAI
import numpy as np
from dotenv import load_dotenv
import os



# ---------------------------------------------------------
# read the connection file and connect to postgres database
# ---------------------------------------------------------
def ConnectDB(file):
    try:
        ret = []
        data = ''
        fp = open(file, "r")

        while True:
            next_line = fp.readline()
            if not next_line:
                break
            data += next_line.strip()
        fp.close()

        if len(data) <= 0:
            ret.extend(["ERROR", "Unable to read the Input data properly. Filename:" + file])
        else:
            parameters = data.split(";")
            keys = [];
            values = []

            for p in parameters:
                if len(p) > 0:
                    sp = p.split(":")
                    keys.append(sp[0])
                    values.append(sp[1])
            conn_values = dict(zip(keys, values))

            # Establish connection to PostgreSQL
            conn = psy.connect(dbname=conn_values['dbname'], user=conn_values['user'],
                               password=conn_values['password'],
                               host=conn_values['host'], port=conn_values['port'])

            cursor = conn.cursor()

            ret.extend(["SUCCESS", conn, cursor])

    except Exception as e:
        ret.extend(["EXCEPTION", "ConnetDB(). " + str(e)])

    return (ret)


# Connect to the pgVector database using the credentials
ret = ConnectDB("pgvector.txt")
if ret[0] == "SUCCESS":
    conn = ret[1]
    cursor = ret[2]
else:
    print("Error / Exception during ConnectDB")

# import os
# print(os.getcwd())

print(conn)

# to create the embeddings, we will use OpenAI embeddings (size 1536)
# client = open()
load_dotenv()
apikey= os.getenv('OPEN_API_KEY')
print(apikey)
client =OpenAI(api_key=apikey)

def SearchData(cursor, cond, qtype, limit=5):
    try:
        qtype = qtype.lower().strip()

        if qtype not in ['meta', 'lex', 'emb', 'reg']:
            data = "Invalid Query Type. Valid values are 'lex','meta','emb','reg'"
        else:
            if qtype == "lex":
                query = f'''
                    select * from supplier_data where supplier_id in ( 
                    select supplier_id from supplier where content_tsv @@ websearch_to_tsquery('english', 
                    '{cond}'))
                    limit {limit} ; '''
            elif qtype == "meta":
                query = f'''
                        select * from supplier_data where supplier_id in ( 
                            select supplier_id from supplier where metadata @> '{cond}') limit {limit} ; '''
            elif qtype == "emb":
                response = client.embeddings.create(model='text-embedding-3-small', input=cond)
                txt_embed = response.data[0].embedding
                query = f''' select * from supplier_data where supplier_id in (
                            select supplier_id from supplier order by embedding <=> '{txt_embed}'::vector 
                            limit {limit} ) '''
            else:
                query = cond

            query = re.sub('[\\n]', ' ', query).strip()
            # print(query)

            cursor.execute(query)
            data = cursor.fetchall()

            cols = [c[0] for c in cursor.description]
            data = pd.DataFrame(data, columns=cols)

    except Exception as e:
        data = str(e)
        data = re.sub("\\n", " ", data).strip()
        data = ' '.join(data.split())

    # return(data,cursor)
    return (data)


# ***************************
# 3) Vector Embeddings Search
# ***************************
qry = "select supplier_id,content from supplier where embedding IS NULL";
data = SearchData(cursor, qry, qtype="reg")
print(data.head())

print(data.columns)
print(data['supplier_id'].tail(20))

# Convert every Content into an embedding; and update table against each supplier ID
# -----------------------------------------------------------------------------------
for i in range(len(data)):
    supplierid, content = data.loc[i, "supplier_id"], data.loc[i, "content"]
    # print(supplierid)
    # print(content)

    response = client.embeddings.create(model="text-embedding-3-small", input=content)
    embedding = response.data[0].embedding  # get the embeddings for the selected review text

    # Convert to PostgreSQL vector format
    embedding_str = "[" + ",".join(map(str, embedding)) + "]"

    # Update database
    cursor.execute("UPDATE supplier SET embedding = %s WHERE supplier_id = %s;", (embedding_str, supplierid))

conn.commit()

#25/03/2026

# write a prompt to fetch data from the table using embedding search
#prompt = "fast delivery"
prompt ="risk band high"
response = client.embeddings.create(model='text-embedding-3-small', input=prompt)
print(response)
# extract only the embeddings
prompt_embed = response.data[0].embedding
print(prompt_embed)

qry = f''' select sd.*, s.embedding <=> '{prompt_embed}'::vector as distance
        from supplier s
        join supplier_data sd
        on sd.supplier_id = s.supplier_id
        order by s.embedding <=> '{prompt_embed}'::vector
        limit 10;
        '''

print(qry)


def executeQuery(query):
    try:
        data = ''

        cursor.execute(query)
        data = cursor.fetchall()

        cols = [c[0] for c in cursor.description]
        data = pd.DataFrame(data, columns=cols)

    except Exception as e:
        data = "Exception." + str(e)

    return (data)

data=executeQuery(qry)
print(data)

data.columns
data[['supplier_id', 'on_time_delivery_pct', 'late_deliveries']].sort_values('on_time_delivery_pct',ascending=False)
data[['supplier_id', 'risk_score']].sort_values('risk_score',ascending=False)
data[['supplier_id', 'risk_score']]

data[['supplier_id', 'risk_score']].query("risk_score > 75").sort_values('risk_score', ascending=False).head(10)

###exaple use case

def search_similar_suppliers(prompt: str, conn, top_k: int = 10):
    """
    Performs semantic similarity search using pgvector.

    Args:
        prompt (str): User input text to embed.
        conn (psycopg.Connection): Active PostgreSQL connection.
        top_k (int): Number of similar rows to return.

    Returns:
        list of dicts: Rows containing supplier data + distance.
    """

    # 1. Generate embedding for the input prompt
    emb_response = client.embeddings.create(
        model="text-embedding-3-small",
        input=prompt
    )
    prompt_embed = emb_response.data[0].embedding  # list of floats

    # 2. SQL query using parameterized vector binding (SAFE)
    sql = """
        SELECT 
            sd.*, 
            s.embedding <=> %s::vector AS distance
        FROM supplier s
        JOIN supplier_data sd 
            ON sd.supplier_id = s.supplier_id
        ORDER BY s.embedding <=> %s::vector
        LIMIT %s;
    """

    # 3. Execute query safely
    with conn.cursor() as cur:
        cur.execute(sql, (prompt_embed, prompt_embed, top_k))
        rows = cur.fetchall()
        colnames = [desc[0] for desc in cur.description]

    # 4. Convert rows → list of dictionaries for easy handling
    result = [dict(zip(colnames, row)) for row in rows]
    return result


results = search_similar_suppliers("Risk band very high", conn)

for r in results:
    print(r["supplier_id"], r["risk_score"])

print(results)
# "SUP1020"	99.74
# "SUP1122"	99.67
# "SUP1605"	99.58
# "SUP1886"	99.56
# "SUP1918"	99.43
# "SUP1327"	99.21
# "SUP1017"	99.02
# "SUP1523"	98.83
# "SUP1224"	98.63
# "SUP1849"	98.59
