from flask import Flask, request, jsonify, render_template
import pandas as pd
import re
from dotenv import load_dotenv
import os
from openai import OpenAI
import psycopg2 as psy




app = Flask(__name__)

load_dotenv()
apikey= os.getenv('OPENAI_API_KEY')
# print(apikey)
client =OpenAI(api_key=apikey)

def ConnectDB(file):
    try:
        ret = []
        data = ''
        fp = open(file, "r")

        while True:
            next_line = fp.readline()
            if not next_line:
                break
            data += next_line.strip()
        fp.close()

        if len(data) <= 0:
            ret.extend(["ERROR", "Unable to read the Input data properly. Filename:" + file])
        else:
            parameters = data.split(";")
            keys = [];
            values = []

            for p in parameters:
                if len(p) > 0:
                    sp = p.split(":")
                    keys.append(sp[0])
                    values.append(sp[1])
            conn_values = dict(zip(keys, values))

            # Establish connection to PostgreSQL
            conn = psy.connect(dbname=conn_values['dbname'], user=conn_values['user'],
                               password=conn_values['password'],
                               host=conn_values['host'], port=conn_values['port'])

            cursor = conn.cursor()

            ret.extend(["SUCCESS", conn, cursor])

    except Exception as e:
        ret.extend(["EXCEPTION", "ConnetDB(). " + str(e)])

    return (ret)

ret = ConnectDB("pgvector.txt")
if ret[0] == "SUCCESS":
    conn = ret[1]
    cursor = ret[2]
else:
    print("Error / Exception during ConnectDB")

#natural language execute function

def ExecuteNLPrompt(cursor, user_query, limit=10, client=None):
    """
    Robust dispatcher for 14 NL prompts.
    - Uses keyword ILIKE fallbacks for reliability.
    - Uses embeddings for ranking when available.
    - Joins bfsi_record (searchable) to bfsi_master_data (clean structured fields).
    - Returns a pandas DataFrame.
    - `client` is optional embedding client; if None, embedding-based ranking is skipped.
    """
    try:
        uq = user_query.lower()
        query = None
        txt_embed = None

        # Helper to build an ORDER BY clause that prefers rows with embeddings but still works if embeddings are NULL
        def embed_order_clause(embed_vector):
            # This orders rows with non-null embedding first, then by distance to embed_vector.
            # If client is None or embed_vector is None, caller should not include this clause.
            return f"(embedding IS NULL), embedding <-> '{embed_vector}'::vector"

        # Prompt 1: Collateral valuation gap / manual review
        if "collateral valuation gap" in uq or "manual review" in uq:
            query = f"""
                SELECT m.case_id, m.case_summary, m.policy_reference
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE content_tsv @@ to_tsquery('collateral | manual')
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 2: Duplicate request closed as duplicate
        elif "duplicate request" in uq:
            query = f"""
                SELECT m.case_id, m.case_status, m.resolution_code, m.resolution_notes
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE (metadata->>'resolution_code') ILIKE '%duplicate%'
                      AND lower(metadata->>'case_status') = 'closed'
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """
        # Prompt 3: High priority Home Loan West open/pending
        elif "high" in uq and "home loan" in uq and "west" in uq:
            query = f"""
                SELECT m.case_id, m.product_type, m.priority, m.region, m.case_status
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'priority'='High'
                      AND metadata->>'product_type'='Home Loan'
                      AND metadata->>'region'='West'
                      AND metadata->>'case_status' IN ('Open','Pending Documents')
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 4: Escalated cases by Disbursement Control with SLA breach
        elif "escalated" in uq and "disbursement control" in uq:
            query = f"""
                SELECT m.case_id, m.business_unit, m.case_status, m.sla_breach_flag
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'business_unit'='Disbursement Control'
                      AND metadata->>'case_status'='Escalated'
                      AND metadata->>'sla_breach_flag'='Yes'
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 5: Insurance pending (hybrid: embedding + keyword fallback)
        elif "insurance document" in uq or "release of funds" in uq:
            # create embedding if client provided
            if client:
                resp = client.embeddings.create(model="text-embedding-3-small",
                                                input="borrower asked for release of funds but insurance document is pending")
                txt_embed = resp.data[0].embedding
            order_clause = embed_order_clause(txt_embed) if txt_embed else "1"
            query = f"""
                SELECT m.case_id, m.case_summary, m.resolution_notes
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE content ILIKE '%insurance%' OR content ILIKE '%release of funds%' OR content ILIKE '%pending document%'
                    ORDER BY {order_clause}
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 6: EMI dispute (hybrid)
        elif "emi" in uq and ("rate revision" in uq or "rate change" in uq):
            if client:
                resp = client.embeddings.create(model="text-embedding-3-small",
                                                input="customer disputes EMI amount after rate revision and requests servicing support")
                txt_embed = resp.data[0].embedding
            order_clause = embed_order_clause(txt_embed) if txt_embed else "1"
            query = f"""
                SELECT m.case_id, m.case_summary, m.resolution_notes
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE content ILIKE '%emi%' OR content ILIKE '%rate revision%' OR content ILIKE '%rate change%' OR content ILIKE '%emi dispute%'
                    ORDER BY {order_clause}
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 7: Average actual TAT by process_name and risk_band for Q3 2025
        elif "average actual tat" in uq and "q3 2025" in uq:
            query = f"""
                SELECT m.process_name, m.risk_band, AVG(m.actual_tat_hours) AS avg_tat
                FROM bfsi_master_data m
                JOIN bfsi_record r ON m.case_id = r.case_id
                WHERE EXTRACT(QUARTER FROM m.created_date) = 3
                  AND EXTRACT(YEAR FROM m.created_date) = 2025
                GROUP BY m.process_name, m.risk_band
                ORDER BY m.process_name, m.risk_band
                LIMIT {limit};
            """

        # Prompt 8: Count closed cases by product_type and region where CSAT < 3.0 (use structured fields)
        elif ("closed cases" in uq and "csat" in uq) or ("below 3" in uq and "csat" in uq):
            query = f"""
                SELECT m.product_type, m.region, COUNT(*) AS closed_case_count
                FROM bfsi_master_data m
                JOIN bfsi_record r ON m.case_id = r.case_id
                WHERE lower(m.case_status) = 'closed'
                  AND m.csat_score IS NOT NULL
                  AND m.csat_score < 3.0
                GROUP BY m.product_type, m.region
                ORDER BY closed_case_count DESC
                LIMIT {limit};
            """

        # Prompt 9: Top 10 cases by transaction_amount_inr with exception_flag = Yes
        elif "highest transaction" in uq or "exception flag" in uq:
            query = f"""
                SELECT m.case_id, m.transaction_amount_inr, m.exception_flag
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'exception_flag'='Yes'
                    ORDER BY (metadata->>'transaction_amount_inr')::numeric DESC
                    LIMIT 10
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 10: Severe-risk Fraud Review North (hybrid)
        elif "fraud review" in uq and "severe" in uq and "north" in uq:
            # response = client.embeddings.create(model="text-embedding-3-small",
            #                                     input="suspicious duplicate documentation")
            # txt_embed = response.data[0].embedding
            query = f"""
                SELECT m.case_id, m.process_name, m.risk_band, m.region, m.case_summary
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE metadata->>'process_name'='Fraud Review'
                      AND metadata->>'risk_band'='Severe'
                      AND metadata->>'region'='North'
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Prompt 11: Sanction delays SME Working Capital with actual_tat_hours > sla_hours (hybrid + flag)
        elif "sanction" in uq and "sme working capital" in uq:
            if client:
                resp = client.embeddings.create(model="text-embedding-3-small",
                                                input="complaints about sanction delays for SME Working Capital")
                txt_embed = resp.data[0].embedding
            order_clause = embed_order_clause(txt_embed) if txt_embed else "1"
            query = f"""
                SELECT m.case_id,
                       m.product_type,
                       m.actual_tat_hours,
                       m.sla_hours,
                       (m.actual_tat_hours > m.sla_hours) AS sla_breached,
                       m.case_summary
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE (metadata->>'product_type' = 'SME Working Capital' OR content ILIKE '%sme working capital%')
                      AND (content ILIKE '%sanction%' OR content ILIKE '%delay%' OR content ILIKE '%sanction delay%')
                    ORDER BY {order_clause}
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id
                WHERE m.product_type = 'SME Working Capital'
                LIMIT {limit};
            """

        # Prompt 12: KYC verification similar to 'name mismatch in income proof' and common root causes (hybrid)
        elif "kyc verification" in uq:
            if client:
                resp = client.embeddings.create(model="text-embedding-3-small",
                                                input="name mismatch in income proof")
                txt_embed = resp.data[0].embedding
            order_clause = embed_order_clause(txt_embed) if txt_embed else "1"
            query = f"""
                SELECT m.root_cause, COUNT(*) AS root_cause_count
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE (metadata->>'process_name'='KYC Verification' OR content ILIKE '%kyc verification%')
                      AND (content ILIKE '%name mismatch%' OR content ILIKE '%income proof%' OR content ILIKE '%name mismatch in income%')
                    ORDER BY {order_clause}
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id
                GROUP BY m.root_cause
                ORDER BY root_cause_count DESC
                LIMIT {limit};
            """

        # Prompt 13: Policy references most frequently associated with escalated AML alerts
        elif "aml alerts" in uq and "escalated" in uq:
            query = f"""
                SELECT m.policy_reference, COUNT(*) AS freq
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE (metadata->>'case_status'='Escalated' OR content ILIKE '%escalat%')
                      AND (content ILIKE '%aml%' OR metadata->>'resolution_notes' ILIKE '%aml%')
                ) r ON m.case_id = r.case_id
                GROUP BY m.policy_reference
                ORDER BY freq DESC
                LIMIT {limit};
            """

        # Prompt 14: Disbursement Hold semantic grouped by channel (hybrid, returns count + case list)
        elif "disbursement hold" in uq:
            if client:
                resp = client.embeddings.create(model="text-embedding-3-small",
                                                input="release funds blocked due to missing document")
                txt_embed = resp.data[0].embedding
            order_clause = embed_order_clause(txt_embed) if txt_embed else "1"
            query = f"""
                SELECT m.channel,
                       COUNT(*) AS case_count,
                       array_agg(m.case_id) AS case_ids
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE (metadata->>'knowledge_article_tag' = 'Disbursement Hold' OR content ILIKE '%disbursement hold%')
                      AND (content ILIKE '%release funds%' OR content ILIKE '%missing document%' OR content ILIKE '%blocked%')
                    ORDER BY {order_clause}
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id
                GROUP BY m.channel
                ORDER BY case_count DESC
                LIMIT {limit};
            """

        # Fallback: general semantic + keyword hybrid
        else:
            if client:
                resp = client.embeddings.create(model="text-embedding-3-small", input=user_query)
                txt_embed = resp.data[0].embedding
            order_clause = embed_order_clause(txt_embed) if txt_embed else "1"
            # fallback to content keyword match + embedding ranking
            query = f"""
                SELECT m.case_id, m.case_summary
                FROM bfsi_master_data m
                JOIN (
                    SELECT case_id
                    FROM bfsi_record
                    WHERE content ILIKE '%{user_query.replace("'", "''")}%' 
                       OR content_tsv @@ plainto_tsquery('{user_query.replace("'", "''")}')
                    ORDER BY {order_clause}
                    LIMIT {limit}
                ) r ON m.case_id = r.case_id;
            """

        # Execute and return DataFrame
        cursor.execute(query)
        rows = cursor.fetchall()
        cols = [c[0] for c in cursor.description]
        # return pd.DataFrame(rows, columns=cols)
        df = pd.DataFrame(rows, columns=cols)
        return df.to_dict(orient="records")

    except Exception as e:
        # Return the error string for debugging in the caller environment
        # return str(e)
        err = str(e)
        err = re.sub("\\n", " ", err).strip()
        err = ' '.join(err.split())
        return {"error": err}


# REST API endpoint
@app.route("/api/execute", methods=["POST"])
def execute_prompt():
    data = request.get_json()
    user_query = data.get("prompt")
    results = ExecuteNLPrompt(cursor, user_query)
    return jsonify({"results": results})

# Frontend route
@app.route("/")
def index():
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)