from sklearn.preprocessing import OneHotEncoder
import pandas as pd

file=r"C:\Users\c04-labuser992564\Downloads\emp.csv"

data = pd.read_csv(file)
print(data)

# identify the category features/columns
data.dtypes

#method1

col = "gender"
onehot = OneHotEncoder(sparse_output=False)
gender_onehot_encoding = onehot.fit_transform(data[[col]])
print(gender_onehot_encoding)

print(data.head(3))

cols = ['gender','dept','education'] # convert these columns into dummy values

data_new = data.copy()

for c in cols:
    dummy = pd.get_dummies(data[c], drop_first=True).astype(int)

for c in cols:
    dummy = pd.get_dummies(data[c], drop_first=True).astype(int)
    data_new = data_new.join(dummy)  # add the new set of columns to the dataset

data_new.drop(columns=col, inplace=True)

print(data_new)
print(data_new.columns)

# display new set of data
data_new[['name', 'Prodcom', 'Purchase', 'R&D', 'Sales']].head(20)
data_new[['dept']].head(20)

# Count Vectorizer
# -----------------
# A CountVectorizer converts a collection of text documents into a matrix of word-frequency counts
# (bag-of-words representation) that machine-learning models can use.

from sklearn.feature_extraction.text import CountVectorizer
# print(CountVectorizer(ngram_range=(1,2)).fit_transform(data[[col]]))

corpus = ['this is an ai event. all ai related news, ai models will be here',
          'ai is the future. future of ai is automation']
print(corpus)
cv = CountVectorizer()
cv1 = cv.fit(corpus)
voc1 = cv1.vocabulary_
print(voc1)

cv2 = cv.fit_transform(corpus)
arr2 = cv2.toarray()
voc2 = cv.get_feature_names_out()

pd.DataFrame(arr2, columns=voc2).T

print((pd.DataFrame(arr2, columns=voc2)))

from pypdf import PdfReader

files = [
    r"C:\Users\c04-labuser992564\Downloads\finance.pdf",
    r"C:\Users\c04-labuser992564\Downloads\healthcare.pdf",
    r"C:\Users\c04-labuser992564\Downloads\retail.pdf"
]
docs = []

# read each PDF and store the data in a list
for f in files:
    data = ""
    reader = PdfReader(f)

    for page in reader.pages:
        data += page.extract_text()
    docs.append(data)

print(docs)
#there are 3 docs, each one in one daomain
len(docs)

# without stopwords removal
cv1 = CountVectorizer()
wc1 = cv1.fit_transform(docs)
arr1 = wc1.toarray()

# unique set of words in all the documents
print(len(arr1[0]), len(arr1[1]), len(arr1[2]))
# print(len(arr1[0]))


# get the list of vocabulary
f1 = cv1.get_feature_names_out()
print(f"CV1. There are {len(f1)} features across {len(docs)} documents")
print(f1)
docs[0]#finanace-109
docs[1]#healthcare-116
docs[2]#retail-96

ndx = ['CTS', 'TATAMOTORS', 'RAMCO']
cp = [1904.2, 785.4, 218.5]
vol = [3.1e3, 4.1e3, 1.04e3]
list(zip(ndx, cp, vol))

# count the words in each of the documents
df_count = pd.concat([
    pd.DataFrame(zip(f1,arr1[0],["finance"]*len(f1)),columns=['word','count','domain']),
    pd.DataFrame(zip(f1,arr1[1],["healthcare"]*len(f1)),columns=['word','count','domain']),
    pd.DataFrame(zip(f1,arr1[2],["retail"]*len(f1)),columns=['word','count','domain'])
], ignore_index=True)

print(df_count)
# get the count of the word to check its occurance
word = "activity"
word1 = "loan"
df_count[df_count["word"] == word1].sort_values("count", ascending=False)

#TF/IDF Vectorization
#Term frequency / Inverse Document Frequency
from sklearn.feature_extraction.text import TfidfVectorizer

corpus = ['meeting went off well',
          'meeting her after a long time',
          'we are meeting the client today',
          'the stakeholder meeting was cancelled today',
          'the meeting is a way to discus progress']

vect = TfidfVectorizer()
tfidf = vect.fit_transform(corpus).toarray()
features = vect.get_feature_names_out()

# store in a dataframe
df_tfidf = pd.DataFrame(tfidf, columns=features)
print(df_tfidf.T)

#stop words
vect1 = TfidfVectorizer(stop_words='english')
tfidf1 = vect1.fit_transform(corpus).toarray()
features = vect1.get_feature_names_out()

# store in a dataframe
df_tfidf1 = pd.DataFrame(tfidf1, columns=features)
print(df_tfidf1.T)


